"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, ShoppingBag, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useToast } from "@/hooks/use-toast"

const jewelryItems = [
  {
    id: 1,
    name: "Royal Bridal Necklace Set",
    category: "Bridal",
    price: "₹85,000",
    originalPrice: "₹95,000",
    image: "/royal-bridal-gold-necklace-set-with-red-stones.jpg",
    isNew: true,
    isBestseller: false,
  },
  {
    id: 2,
    name: "Diamond Engagement Ring",
    category: "Western",
    price: "₹45,000",
    originalPrice: null,
    image: "/elegant-diamond-engagement-ring-white-gold.jpg",
    isNew: false,
    isBestseller: true,
  },
  {
    id: 3,
    name: "Traditional Temple Jewelry",
    category: "Bridal",
    price: "₹65,000",
    originalPrice: "₹75,000",
    image: "/traditional-south-indian-temple-jewelry-gold.jpg",
    isNew: false,
    isBestseller: false,
  },
  {
    id: 4,
    name: "Pearl Drop Earrings",
    category: "Western",
    price: "₹12,000",
    originalPrice: null,
    image: "/elegant-pearl-drop-earrings-white-gold.jpg",
    isNew: true,
    isBestseller: false,
  },
  {
    id: 5,
    name: "Kundan Bridal Set",
    category: "Bridal",
    price: "₹1,25,000",
    originalPrice: "₹1,40,000",
    image: "/kundan-bridal-jewelry-set-with-emeralds.jpg",
    isNew: false,
    isBestseller: true,
  },
  {
    id: 6,
    name: "Rose Gold Bracelet",
    category: "Western",
    price: "₹25,000",
    originalPrice: null,
    image: "/rose-gold-bracelet-with-diamonds-modern-design.jpg",
    isNew: false,
    isBestseller: false,
  },
]

export default function WishlistPage() {
  const [wishlist, setWishlist] = useState<number[]>([])
  const [isLoaded, setIsLoaded] = useState(false)
  const { toast } = useToast()

  useEffect(() => {
    const loadWishlist = () => {
      try {
        if (typeof window !== "undefined") {
          const savedWishlist = localStorage.getItem("trendy-jewels-wishlist")
          if (savedWishlist) {
            const parsed = JSON.parse(savedWishlist)
            setWishlist(parsed)
          }
        }
      } catch (error) {
        console.error("Failed to load wishlist:", error)
      } finally {
        setIsLoaded(true)
      }
    }

    loadWishlist()
  }, [])

  const removeFromWishlist = (itemId: number, itemName: string) => {
    setWishlist((prev) => {
      const newWishlist = prev.filter((id) => id !== itemId)

      try {
        if (typeof window !== "undefined") {
          localStorage.setItem("trendy-jewels-wishlist", JSON.stringify(newWishlist))
        }
      } catch (error) {
        console.error("Failed to save wishlist:", error)
      }

      toast({
        title: "Removed from Wishlist",
        description: `${itemName} removed from your wishlist`,
      })

      return newWishlist
    })
  }

  const handleBookNow = (itemName: string) => {
    // Navigate to home page and scroll to booking section
    window.location.href = `/#booking`
  }

  const wishlistItems = jewelryItems.filter((item) => wishlist.includes(item.id))

  if (!isLoaded) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading your wishlist...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Collections
            </Link>
          </Button>
        </div>

        <div className="text-center space-y-4 mb-12">
          <h1 className="text-3xl lg:text-4xl font-bold text-balance">My Wishlist</h1>
          <p className="text-xl text-muted-foreground text-pretty max-w-2xl mx-auto">
            {wishlistItems.length > 0
              ? `You have ${wishlistItems.length} item${wishlistItems.length > 1 ? "s" : ""} in your wishlist`
              : "Your wishlist is empty. Start adding your favorite jewelry pieces!"}
          </p>
        </div>

        {wishlistItems.length === 0 ? (
          <div className="text-center py-16">
            <Heart className="w-16 h-16 text-muted-foreground mx-auto mb-6" />
            <h3 className="text-xl font-semibold mb-4">Your wishlist is empty</h3>
            <p className="text-muted-foreground mb-8 max-w-md mx-auto">
              Browse our beautiful collections and add items to your wishlist by clicking the heart icon.
            </p>
            <Button asChild>
              <Link href="/#collections">Browse Collections</Link>
            </Button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {wishlistItems.map((item) => (
              <Card key={item.id} className="group overflow-hidden hover:shadow-lg transition-all duration-300">
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={item.image || "/placeholder.svg"}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />

                  <div className="absolute top-4 left-4 flex flex-col gap-2">
                    {item.isNew && <Badge className="bg-primary text-primary-foreground">New</Badge>}
                    {item.isBestseller && <Badge variant="secondary">Bestseller</Badge>}
                  </div>

                  <button
                    onClick={() => removeFromWishlist(item.id, item.name)}
                    className="absolute top-4 right-4 w-10 h-10 bg-red-500 text-white backdrop-blur rounded-full flex items-center justify-center transition-all duration-300 hover:scale-110 hover:bg-red-600"
                  >
                    <Heart className="w-5 h-5 fill-current" />
                  </button>

                  <div className="absolute bottom-4 left-4 right-4 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Button size="sm" className="flex-1" onClick={() => handleBookNow(item.name)}>
                      <ShoppingBag className="w-4 h-4 mr-2" />
                      Book Now
                    </Button>
                  </div>
                </div>

                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        {item.category}
                      </Badge>
                    </div>

                    <h3 className="font-semibold text-lg text-balance leading-tight">{item.name}</h3>

                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-primary">{item.price}</span>
                      {item.originalPrice && (
                        <span className="text-sm text-gray-900 line-through">{item.originalPrice}</span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {wishlistItems.length > 0 && (
          <div className="text-center mt-12">
            <Button asChild variant="outline">
              <Link href="/#collections">Continue Shopping</Link>
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
