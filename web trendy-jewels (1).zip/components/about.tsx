import { Card, CardContent } from "@/components/ui/card"
import { Shield, Award, Gem, Users } from "lucide-react"

const features = [
  {
    icon: Shield,
    title: "Certified Quality",
    description: "All our jewelry comes with proper certification and quality assurance",
  },
  {
    icon: Award,
    title: "15+ Years Experience",
    description: "Trusted by thousands of customers across Sivakasi and Tamil Nadu",
  },
  {
    icon: Gem,
    title: "Premium Materials",
    description: "We use only the finest gold, diamonds, and precious stones",
  },
  {
    icon: Users,
    title: "Expert Craftsmanship",
    description: "Our skilled artisans create each piece with attention to detail",
  },
]

export function About() {
  return (
    <section id="about" className="py-20 bg-muted/50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h2 className="text-3xl lg:text-4xl font-bold text-balance">Why Choose Trendy Jewels?</h2>
              <p className="text-xl text-muted-foreground text-pretty leading-relaxed">
                Located in the heart of Sivakasi, Trendy Jewels has been creating beautiful memories for over 15 years.
                We specialize in both traditional bridal jewelry and contemporary western designs, ensuring every
                customer finds their perfect piece.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <Card key={index} className="border-0 shadow-none bg-background/50">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                        <feature.icon className="w-6 h-6 text-primary" />
                      </div>
                      <h3 className="font-semibold text-lg">{feature.title}</h3>
                      <p className="text-muted-foreground text-sm leading-relaxed">{feature.description}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="aspect-[4/5] rounded-2xl overflow-hidden bg-muted">
              <img
                src="/jewelry-shop-interior-with-display-cases-and-elega.jpg"
                alt="Trendy Jewels shop interior"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Stats overlay */}
            <div className="absolute bottom-6 left-6 right-6 bg-background/95 backdrop-blur rounded-xl p-6">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-primary">5000+</div>
                  <div className="text-sm text-muted-foreground">Happy Customers</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-primary">15+</div>
                  <div className="text-sm text-muted-foreground">Years Experience</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
