"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X, Phone, MapPin, Heart } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  const scrollToSection = (sectionId: string) => {
    console.log("[v0] Navigation clicked for section:", sectionId)

    const element = document.getElementById(sectionId)
    console.log("[v0] Element found:", element ? "Yes" : "No")

    if (element) {
      const headerHeight = 80
      let elementPosition = element.offsetTop
      let offsetParent = element.offsetParent as HTMLElement

      // Calculate total offset from document top
      while (offsetParent) {
        elementPosition += offsetParent.offsetTop
        offsetParent = offsetParent.offsetParent as HTMLElement
      }

      const offsetPosition = elementPosition - headerHeight

      console.log("[v0] Element position:", elementPosition)
      console.log("[v0] Calculated scroll position:", offsetPosition)

      window.scrollTo({
        top: Math.max(0, offsetPosition),
        behavior: "smooth",
      })

      console.log("[v0] Scroll command executed")

      setTimeout(() => {
        console.log("[v0] Final scroll position:", window.scrollY)
      }, 1000)
    } else {
      console.log("[v0] Element not found with ID:", sectionId)
    }

    setIsMenuOpen(false)
  }

  return (
    <header className="bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50 border-b border-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">TJ</span>
            </div>
            <span className="font-bold text-xl text-foreground">Trendy Jewels</span>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <button
              onClick={() => scrollToSection("collections")}
              className="text-foreground hover:text-primary transition-colors cursor-pointer px-2 py-1 rounded hover:bg-accent"
            >
              Collections
            </button>
            <button
              onClick={() => scrollToSection("about")}
              className="text-foreground hover:text-primary transition-colors cursor-pointer px-2 py-1 rounded hover:bg-accent"
            >
              About
            </button>
            <button
              onClick={() => scrollToSection("testimonials")}
              className="text-foreground hover:text-primary transition-colors cursor-pointer px-2 py-1 rounded hover:bg-accent"
            >
              Reviews
            </button>
            <Link
              href="/wishlist"
              className="text-foreground hover:text-primary transition-colors flex items-center gap-2 px-2 py-1 rounded hover:bg-accent"
            >
              <Heart className="w-4 h-4" />
              Wishlist
            </Link>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <MapPin className="w-4 h-4" />
              <span>Sivakasi</span>
            </div>
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Phone className="w-4 h-4" />
              <span>+91 98765 43210</span>
            </div>
            <Button onClick={() => scrollToSection("booking")}>Book Consultation</Button>
          </div>

          {/* Mobile menu button */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-border">
            <nav className="flex flex-col space-y-4">
              <button
                onClick={() => scrollToSection("collections")}
                className="text-foreground hover:text-primary transition-colors text-left cursor-pointer px-2 py-1 rounded hover:bg-accent"
              >
                Collections
              </button>
              <button
                onClick={() => scrollToSection("about")}
                className="text-foreground hover:text-primary transition-colors text-left cursor-pointer px-2 py-1 rounded hover:bg-accent"
              >
                About
              </button>
              <button
                onClick={() => scrollToSection("testimonials")}
                className="text-foreground hover:text-primary transition-colors text-left cursor-pointer px-2 py-1 rounded hover:bg-accent"
              >
                Reviews
              </button>
              <Link
                href="/wishlist"
                className="text-foreground hover:text-primary transition-colors flex items-center gap-2 px-2 py-1 rounded hover:bg-accent"
                onClick={() => setIsMenuOpen(false)}
              >
                <Heart className="w-4 h-4" />
                Wishlist
              </Link>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <Phone className="w-4 h-4" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span>Sivakasi, Tamil Nadu</span>
              </div>
              <Button onClick={() => scrollToSection("booking")} className="w-full">
                Book Consultation
              </Button>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
