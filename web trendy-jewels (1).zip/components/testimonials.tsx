import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const testimonials = [
  {
    name: "Priya Sharma",
    location: "Sivakasi",
    rating: 5,
    text: "Absolutely stunning bridal jewelry! The team at Trendy Jewels helped me find the perfect set for my wedding. The quality is exceptional and the service was outstanding.",
    occasion: "Bridal Jewelry",
  },
  {
    name: "Rajesh Kumar",
    location: "Madurai",
    rating: 5,
    text: "Bought an engagement ring for my fiancée and she loved it! The diamond quality is excellent and the design is exactly what we wanted. Highly recommended!",
    occasion: "Engagement Ring",
  },
  {
    name: "Meera Patel",
    location: "Virudhunagar",
    rating: 5,
    text: "The booking process was so convenient and the consultation was very helpful. They understood exactly what I was looking for and delivered beyond expectations.",
    occasion: "Western Jewelry",
  },
]

export function Testimonials() {
  return (
    <section id="testimonials" className="py-20 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-balance">What Our Customers Say</h2>
          <p className="text-xl text-muted-foreground text-pretty max-w-2xl mx-auto">
            Don't just take our word for it - hear from our satisfied customers
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="h-full">
              <CardContent className="p-6 h-full flex flex-col">
                {/* Rating */}
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-primary text-primary" />
                  ))}
                </div>

                {/* Testimonial Text */}
                <blockquote className="text-muted-foreground leading-relaxed mb-6 flex-grow">
                  "{testimonial.text}"
                </blockquote>

                {/* Customer Info */}
                <div className="space-y-2">
                  <div className="font-semibold">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">{testimonial.location}</div>
                  <div className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full inline-block">
                    {testimonial.occasion}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
