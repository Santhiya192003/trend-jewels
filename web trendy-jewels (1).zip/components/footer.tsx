"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MapPin, Phone, Mail, Clock, Facebook, Instagram, Twitter } from "lucide-react"
import { useState } from "react"

export function Footer() {
  const [phoneNumber, setPhoneNumber] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleBooking = async () => {
    if (!phoneNumber.trim()) {
      alert("Please enter your phone number")
      return
    }

    if (phoneNumber.length < 10) {
      alert("Please enter a valid phone number")
      return
    }

    setIsSubmitting(true)

    // Simulate booking submission
    setTimeout(() => {
      alert(`Thank you! We'll call you at ${phoneNumber} to schedule your consultation.`)
      setPhoneNumber("")
      setIsSubmitting(false)
    }, 1000)
  }

  return (
    <footer className="bg-muted/30 border-t border-border">
      {/* Booking CTA Section */}
      <section id="booking" className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto space-y-6">
            <h2 className="text-3xl lg:text-4xl font-bold text-balance">Ready to Find Your Perfect Jewelry?</h2>
            <p className="text-xl opacity-90 text-pretty">
              Book a consultation with our jewelry experts and discover pieces that celebrate your unique style
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Input
                type="tel"
                placeholder="Enter your phone number"
                className="bg-primary-foreground text-foreground"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleBooking()}
              />
              <Button
                variant="secondary"
                size="lg"
                className="whitespace-nowrap"
                onClick={handleBooking}
                disabled={isSubmitting}
              >
                {isSubmitting ? "Booking..." : "Book Now"}
              </Button>
            </div>
            <p className="text-sm opacity-75">
              Or call us directly at <strong>+91 98765 43210</strong>
            </p>
          </div>
        </div>
      </section>

      {/* Main Footer */}
      <div className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <span className="text-primary-foreground font-bold text-sm">TJ</span>
                </div>
                <span className="font-bold text-xl">Trendy Jewels</span>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Creating beautiful memories with exquisite jewelry for over 15 years in Sivakasi.
              </p>
              <div className="flex space-x-4">
                <Button size="sm" variant="outline" className="w-10 h-10 p-0 bg-transparent">
                  <Facebook className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="w-10 h-10 p-0 bg-transparent">
                  <Instagram className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="w-10 h-10 p-0 bg-transparent">
                  <Twitter className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Quick Links */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Quick Links</h3>
              <nav className="flex flex-col space-y-2">
                <Link href="#collections" className="text-muted-foreground hover:text-primary transition-colors">
                  Collections
                </Link>
                <Link href="#about" className="text-muted-foreground hover:text-primary transition-colors">
                  About Us
                </Link>
                <Link href="#testimonials" className="text-muted-foreground hover:text-primary transition-colors">
                  Reviews
                </Link>
                <Link href="#booking" className="text-muted-foreground hover:text-primary transition-colors">
                  Book Consultation
                </Link>
              </nav>
            </div>

            {/* Collections */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Collections</h3>
              <nav className="flex flex-col space-y-2">
                <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Bridal Jewelry
                </Link>
                <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Western Jewelry
                </Link>
                <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Engagement Rings
                </Link>
                <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                  Traditional Sets
                </Link>
              </nav>
            </div>

            {/* Contact Info */}
            <div className="space-y-4">
              <h3 className="font-semibold text-lg">Contact Info</h3>
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <div className="text-muted-foreground">
                    <div>123 Main Street</div>
                    <div>Sivakasi, Tamil Nadu</div>
                    <div>626123</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">+91 98765 43210</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                  <span className="text-muted-foreground">info@trendyjewels.com</span>
                </div>
                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
                  <div className="text-muted-foreground">
                    <div>Mon - Sat: 10 AM - 8 PM</div>
                    <div>Sunday: 11 AM - 6 PM</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-border py-6">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-muted-foreground text-sm">© 2024 Trendy Jewels. All rights reserved.</p>
            <div className="flex space-x-6 text-sm">
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Terms of Service
              </Link>
              <Link href="#" className="text-muted-foreground hover:text-primary transition-colors">
                Return Policy
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
