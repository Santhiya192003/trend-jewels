import { Button } from "@/components/ui/button"
import { Sparkles, Award, Users } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-background to-muted py-20 lg:py-32">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-4xl lg:text-6xl font-bold text-balance leading-tight">
                Exquisite Jewelry for
                <span className="text-primary block">Life's Special Moments</span>
              </h1>
              <p className="text-xl text-muted-foreground text-pretty leading-relaxed">
                Discover our stunning collection of bridal and western jewelry at Trendy Jewels, Sivakasi. Each piece is
                carefully crafted to celebrate your unique style and precious moments.
              </p>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap gap-8">
              <div className="flex items-center space-x-2">
                <Award className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">15+ Years Experience</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">5000+ Happy Customers</span>
              </div>
              <div className="flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-primary" />
                <span className="text-sm font-medium">Premium Quality</span>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild>
                <Link href="#collections">Explore Collections</Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link href="#booking">Book Consultation</Link>
              </Button>
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative">
            <div className="aspect-square rounded-2xl overflow-hidden bg-muted">
              <img
                src="/elegant-bridal-jewelry-necklace-with-diamonds-and-.jpg"
                alt="Elegant bridal jewelry collection"
                className="w-full h-full object-cover"
              />
            </div>
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 bg-primary text-primary-foreground px-4 py-2 rounded-full text-sm font-medium">
              New Collection
            </div>
            <div className="absolute -bottom-4 -left-4 bg-background shadow-lg px-4 py-2 rounded-full text-sm font-medium border">
              Premium Quality
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
